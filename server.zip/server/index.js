import "dotenv/config";
import express from "express";
import multer from "multer";
import cors from "cors";
// import fs from "fs/promises";
import { GoogleGenAI } from "@google/genai";

const app = express();
const upload = multer();
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const GEMINI_MODEL = "gemini-3.5-flash-lite"; // Pastikan versi model sesuai

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Server API berjalan dengan baik 🚀");
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server ready on http://localhost:${PORT}`));

app.post("/generate-text", async (req, res) => {
  const { prompt } = req.body;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
    });
    res.status(200).json({ result: response.text });
  } catch (e) {
    console.log(e);
    res.status(500).json({ message: e.message });
  }
});

app.post("/generate-from-image", upload.single("image"), async (req, res) => {
  const { prompt } = req.body;

  try {
    if (!req.file) {
      return res.status(400).json({
        message: "File image wajib dikirim dengan field 'image'",
      });
    }

    const base64Image = req.file.buffer.toString("base64");

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: [
        {
          role: "user",
          parts: [
            {
              text: prompt || "Tolong jelaskan gambar ini.",
            },
            {
              inlineData: {
                data: base64Image,
                mimeType: req.file.mimetype,
              },
            },
          ],
        },
      ],
    });

    res.status(200).json({
      result: response.text,
    });
  } catch (e) {
    console.log(e);

    res.status(500).json({
      message: e.message,
    });
  }
});

app.post(
  "/generate-from-document",
  upload.single("document"),
  async (req, res) => {
    const { prompt } = req.body;

    try {
      if (!req.file) {
        return res.status(400).json({
          message: "File document wajib dikirim dengan field 'document'",
        });
      }

      const base64Document = req.file.buffer.toString("base64");

      const response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: [
          {
            role: "user",
            parts: [
              {
                text: prompt || "Tolong buat ringkasan dari document tersebut.",
              },
              {
                inlineData: {
                  data: base64Document,
                  mimeType: req.file.mimetype,
                },
              },
            ],
          },
        ],
      });

      res.status(200).json({
        result: response.text,
      });
    } catch (e) {
      console.log(e);

      res.status(500).json({
        message: e.message,
      });
    }
  },
);

app.post("/generate-from-audio", upload.single("audio"), async (req, res) => {
  const { prompt } = req.body;
  const base64Audio = req.file.buffer.toString("base64");

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: [
        {
          text: prompt ?? "Tolong buat transkrip dari rekaman tersebut",
          type: "text",
        },
        { inlineData: { data: base64Audio, mimeType: req.file.mimetype } },
      ],
    });
    res.status(200).json({ result: response.text });
  } catch (e) {
    console.log(e);
    res.status(500).json({ message: e.message });
  }
});

app.post("/api/chat", async (req, res) => {
  const { conversation } = req.body;
  try {
    if (!Array.isArray(conversation))
      throw new Error("Messages must be an array!");

    const contents = conversation.map(({ role, text }) => ({
      role,
      parts: [{ text }],
    }));

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents,
      config: {
        temperature: 0.9,
        // systemInstruction: "Jawab hanya menggunakan bahasa Indonesia",
        systemInstruction: `
Kamu adalah School Assistant, yaitu asisten informasi resmi sekolah.

Tugas kamu adalah membantu siswa, orang tua, guru, dan calon siswa
mendapatkan informasi seputar sekolah.

Kamu dapat membantu menjawab pertanyaan mengenai:
- informasi akademik
- jadwal pelajaran
- kegiatan sekolah
- ekstrakurikuler
- fasilitas sekolah
- tata tertib
- pendaftaran siswa
- informasi guru dan staf
- informasi umum sekolah

Gunakan bahasa Indonesia yang ramah, sopan, jelas, dan mudah dipahami.

Jika informasi yang ditanyakan tidak tersedia dalam konteks yang diberikan,
jangan mengarang informasi. Katakan bahwa informasi tersebut belum tersedia
dan sarankan pengguna menghubungi pihak sekolah.

Jangan mengklaim sebagai manusia.
Identitas kamu adalah School Assistant.

Jawab hanya menggunakan bahasa Indonesia.
`,
      },
    });
    res.status(200).json({ result: response.text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
